<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindlu");
}
include "koneksi.php";
require "functions.php";

$no = $_GET['no'];

// Mengambil nama file foto yang terkait dengan postingan yang akan dihapus
$sqlGetImage = "SELECT foto FROM post WHERE no = '$no'";
$queryGetImage = mysqli_query($koneksi, $sqlGetImage);
$rowImage = mysqli_fetch_assoc($queryGetImage);
$foto = $rowImage['foto'];

// Menghitung jumlah total postingan
$sqlCount = "SELECT COUNT(*) as total FROM post";
$queryCount = mysqli_query($koneksi, $sqlCount);
$rowCount = mysqli_fetch_assoc($queryCount);
$totalPostingan = $rowCount['total'];

if ($totalPostingan > 1) {
    // Hapus postingan dari database
    $sqlDelete = "DELETE FROM post WHERE no = '$no'";
    $queryDelete = mysqli_query($koneksi, $sqlDelete);

    if ($queryDelete) {
        // Hapus file foto terkait
        unlink("gambar/" . $foto);

        header("location:index.php?hapus=sukses");
    } else {
        header("location:index.php?hapus=gagal");
    }
} else {
    // Jika hanya satu postingan yang tersisa, tidak lakukan penghapusan
    header("location:index.php?hapus=gagal");
}
?>
