<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindlu");
}
include "koneksi.php";
include "sidebar.php";
// $no = $_GET['no'];

// $sql1 = "SELECT * FROM post WHERE no = '$no' ";
// $query1 = mysqli_query($koneksi, $sql1);

$sql = "SELECT * FROM post";
$query = mysqli_query($koneksi, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Infinity</title>
    <link rel="icon" type="image/x-icon" href="meika.ico">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <style>
        .card-img-top {
            max-width: 1000px; /* Sesuaikan dengan lebar yang Anda inginkan */
            height: 500px; /* Untuk menjaga aspek rasio gambar */
        }
        .square-image {
    position: relative;
    overflow: hidden;
    padding-top: 100%; /* 1:1 Aspect Ratio */
}

.square-image img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover; /* Untuk memotong gambar jika perlu */
}

    </style>
</head>
<body>
<div class="container">
    <div class="row">
        <?php while ($post = mysqli_fetch_assoc($query)) { ?>
            <div class="col-md-3 mb-3">
                <!-- Gambar -->
                <div class="card">
                    <div class="square-image">
                        <img src="gambar/<?= $post['foto'] ?>" class="card-img-top" alt="...">
                    </div>
                </div>
            </div>
        <?php } ?>

        
        </div>
    </div>
</body>


<?php 
      $sql1 = "SELECT * FROM post";
      $query1 = mysqli_query($koneksi, $sql);
      while ($row = mysqli_fetch_assoc($query1)) { ?> 
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Postingan</h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      
      <div class="modal-body">
       
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">

        <label for="foto" class="form-label">image</label><br>
        <input type="file" name="foto" id="" class="form-control"><br>

        <label for="caption" class="form-label">caption</label><br>
        <input type="text" name="caption" id="" class="form-control"><br>

        <label for="lokasi" class="form-label">location</label><br>
        <input type="text" name="lokasi" id="" class="form-control"><br>

        

      </div>
      <div class="modal-footer">
      <input type="submit" value="simpan" name="simpan" class="btn btn-secondary">
        <a href="index.php" class="btn btn-dark">kembali</a> </div>
        </form>
    </div>
  </div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
  integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
  crossorigin="anonymous"></script>

<?php } ?>


<?php 
      $sql1 = "SELECT * FROM post";
      $query1 = mysqli_query($koneksi, $sql);
      while ($row = mysqli_fetch_assoc($query1)) { ?> 
<div class="modal fade" id="exampleModal1<?=$row['no']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Postingan</h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      
      <div class="modal-body">
       
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
 
          <input type="hidden" name="no" value="<?=$row['no']?>">
        <label for="foto" class="form-label">image</label><br>
        <input type="file" name="foto" id="" class="form-control" value="<?=$row['foto']?>"><br>

        <label for="caption" class="form-label">caption</label><br>
        <input type="text" name="caption" id="" class="form-control" value="<?=$row['caption']?>"><br>

        <label for="lokasi" class="form-label">location</label><br>
        <input type="text" name="lokasi" id="" class="form-control" value="<?=$row['lokasi']?>"><br>

        

      </div>
      <div class="modal-footer">
      <input type="submit" value="edit" name="update" class="btn btn-secondary">
        <a href="index.php" class="btn btn-dark">kembali</a> </div>
        </form>
    </div>
  </div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
  integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
  crossorigin="anonymous"></script>

<?php } ?>


	
      </body>