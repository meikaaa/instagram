<?php
include "koneksi.php";

$password = md5($_POST['password']); // Enkripsi password menggunakan md5
$username = $_POST['username'];

// Gunakan prepared statement
$sql = "UPDATE user SET username=?, password=?";
$stmt = mysqli_prepare($koneksi, $sql);

// Periksa apakah statement berhasil dibuat
if ($stmt) {
    // Bind parameter
    mysqli_stmt_bind_param($stmt, "ss", $username, $password);

    // Eksekusi statement
    $result = mysqli_stmt_execute($stmt);

    // Periksa apakah update berhasil
    if ($result) {
        header("location:index.php?update_berhasil");
    } else {
        header("location:index.php?update_gagal");
    }

    // Tutup statement
    mysqli_stmt_close($stmt);
} else {
    header("location:index.php?update_gagal");
}

// Tutup koneksi
mysqli_close($koneksi);
?>
