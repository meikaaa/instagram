<?php
session_start();

// Cek apakah pengguna telah login, jika tidak, arahkan ke halaman login
if (!isset($_SESSION['login'])) {
    header("location: login.php?pesan=logindulu");
    exit;
}
include "koneksi.php";
include "sidebar.php";
// Ambil data pengguna yang sedang login dari sesi
$username = $_SESSION['login'];

// ... selanjutnya, Anda bisa menggunakan $username untuk mengisi formulir
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Ganti Password</title>
</head>
<body><br><br>
<div class="container">
    <div class="col-md-8">
        <h3>Edit Akun</h3>
        <div class="card mb-4">
            <div class="card-body">
                <form action="changePassword.php" method="POST">
                    <div class="form-group">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" id="username" value="<?php echo $username; ?>" readonly >
                    </div>
            <br>
                    <div class="form-group">
                        <label for="passwordbaru" class="form-label">Password Baru</label>
                        <input type="password" class="form-control" name="password" id="passwordbaru">
                    </div>

                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="showPassword">
                        <label class="form-check-label" for="showPassword">Tampilkan Password</label>
                        <br><br>
                    </div>

                    <div class="form-group">
                        <input type="submit" name="change" value="Ganti" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById("showPassword").addEventListener("change", function () {
        var passwordInput = document.getElementById("passwordbaru");
        if (this.checked) {
            passwordInput.type = "text";
        } else {
            passwordInput.type = "password";
        }
    });
</script>

</body>
</html>
