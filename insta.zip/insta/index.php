<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindlu");
}
include "koneksi.php";
include "sidebar.php";
// $no = $_GET['no'];

// $sql1 = "SELECT * FROM post WHERE no = '$no' ";
// $query1 = mysqli_query($koneksi, $sql1);

$sql = "SELECT * FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Infinity</title>
    <link rel="icon" type="image/x-icon" href="meika.ico">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
<style>
        body {
            background-color: #e9ecef; /* Use the Bootstrap secondary background color */
        }
        .card-img-top {
            max-width: 1000px; /* Sesuaikan dengan lebar yang Anda inginkan */
            height: 500px; /* Untuk menjaga aspek rasio gambar */
        }
        .img-hover-zoom {
            height: 500px; /* Set it as per your need */
            overflow: hidden; /* Hide the overflowing of child elements */
        }
        .img-hover-zoom img {
            transition: transform .5s ease; /* Transition property for smooth transformation of images */
        }
        .img-hover-zoom:hover img {
            transform: scale(1.5); /* Transforming the image when container gets hovered */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php while ($post = mysqli_fetch_assoc($query)){?>
                    <!-- Postingan -->
                    <div class="card mb-4">
                        <div class="card-header">
                          
                            <strong><?=$_SESSION['login']?></strong>
                            <p><?=$post['lokasi']?></p>
                        </div>
                        <div class="img-hover-zoom">
                            <img src="gambar/<?=$post['foto']?>" class="card-img-top" alt="...">
                        </div>
                        <div class="card-body">
                            <h6 class="card-title"><strong>@<?=$_SESSION['login']?></strong>    <?=$post['caption']?></h6>
                            <br>
                            <div class="d-flex">
        <div>
            <a href="hapus.php?no=<?=$post['no']?>" class="btn btn-primary btn-sm" onclick="return confirm('Apakah anda yakin ingin menghapus data ini?')"><i class="fas fa-trash"></i></a>
            <a class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal1<?=$post['no']?>"><i class="fa fa-edit"></i></a>
        </div>
    </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</body>




<?php 
      $sql1 = "SELECT * FROM post";
      $query1 = mysqli_query($koneksi, $sql);
      while ($row = mysqli_fetch_assoc($query1)) { ?> 
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Postingan</h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      
      <div class="modal-body">
       
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">

        <label for="foto" class="form-label">image</label><br>
        <input type="file" name="foto" id="" class="form-control"><br>

        <label for="caption" class="form-label">caption</label><br>
        <input type="text" name="caption" id="" class="form-control"><br>

        <label for="lokasi" class="form-label">location</label><br>
        <input type="text" name="lokasi" id="" class="form-control"><br>

        

      </div>
      <div class="modal-footer">
      <input type="submit" value="simpan" name="simpan" class="btn btn-secondary">
        <a href="index.php" class="btn btn-dark">kembali</a> </div>
        </form>
    </div>
  </div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
  integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
  crossorigin="anonymous"></script>

<?php } ?>


<?php 
      $sql1 = "SELECT * FROM post";
      $query1 = mysqli_query($koneksi, $sql);
      while ($row = mysqli_fetch_assoc($query1)) { ?> 
<div class="modal fade" id="exampleModal1<?=$row['no']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Postingan</h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      
      <div class="modal-body">
       
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
 
          <input type="hidden" name="no" value="<?=$row['no']?>">
          <input type="hidden" name="foto_lama" value="<?= $row['foto'] ?>">
        <label for="foto" class="form-label">image</label><br>
        <input type="file" name="foto" id="" class="form-control" value="<?=$row['foto']?>"><br>
          
        <label for="caption" class="form-label">caption</label><br>
        <input type="text" name="caption" id="" class="form-control" value="<?=$row['caption']?>"><br>

        <label for="lokasi" class="form-label">location</label><br>
        <input type="text" name="lokasi" id="" class="form-control" value="<?=$row['lokasi']?>"><br>

        <img src="gambar/<?= $row['foto'] ?>" width="100px" alt="" ><br>
        

      </div>
      <div class="modal-footer">
      <input type="submit" value="edit" name="update" class="btn btn-secondary">
        <a href="index.php" class="btn btn-dark">kembali</a> </div>
        </form>
    </div>
  </div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
  integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
  crossorigin="anonymous"></script>

<?php } ?>


<!-- Modal Pencarian -->
<div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="searchModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="searchModalLabel">Cari Postingan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <!-- Form Pencarian -->
        <form id="searchForm">
          <div class="form-group">
            <label for="keyword">Kata Kunci</label><br>
            <input type="text" class="form-control" id="keyword" name="keyword" placeholder="Mulai mengetik untuk mencari...">
          </div>
        </form>
        <!-- Hasil Pencarian -->
        <div id="searchResults">
          <!-- Hasil pencarian akan ditampilkan di sini -->
        </div>
      </div>
    </div>
  </div>
</div>



      </body>
      <script>
// Fungsi untuk menampilkan hasil pencarian dalam modal
function showSearchResults(results) {
    var searchResults = document.getElementById('searchResults');
    searchResults.innerHTML = ''; // Kosongkan konten modal pencarian sebelumnya

    // Loop melalui hasil pencarian dan tambahkan ke modal
    for (var i = 0; i < results.length; i++) {
        var post = results[i];

        var card = document.createElement('div');
        card.className = 'card mb-4';

        var cardHeader = document.createElement('div');
        cardHeader.className = 'card-header';
        cardHeader.innerHTML = '<strong>' + post.login + '</strong><p>' + post.lokasi + '</p>';

        var imgContainer = document.createElement('div');
        imgContainer.className = 'img-hover-zoom';
        var img = document.createElement('img');
        img.src = 'gambar/' + post.foto;
        img.className = 'card-img-top';
        img.alt = '...';
        imgContainer.appendChild(img);

        var cardBody = document.createElement('div');
        cardBody.className = 'card-body';
        cardBody.innerHTML = '<h6 class="card-title"><strong>@' + post.login + '</strong> ' + post.caption + '</h6><br><div class="d-flex justify-content-between"><div><a href="#"><i class="fas fa-heart fa-2x"></i></a><a href="#" style="margin-left: 10px;"><i class="far fa-comment fa-2x"></i></a></div><div class="dropdown"><button class="btn btn-link" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">•••</button><div class="dropdown-menu" aria-labelledby="dropdownMenuButton"><a class="dropdown-item" href="#" data-toggle="modal" data-target="#exampleModal1' + post.no + '">Edit</a><a class="dropdown-item" href="hapus.php?no=' + post.no + '">Hapus</a></div></div></div>';

        card.appendChild(cardHeader);
        card.appendChild(imgContainer);
        card.appendChild(cardBody);

        searchResults.appendChild(card);
    }
}

// Fungsi untuk mengirim permintaan pencarian dan menampilkan hasilnya dalam modal
function searchPosts() {
    var keyword = document.getElementById('keyword').value;

    // Lakukan AJAX request ke server untuk mencari postingan berdasarkan keyword
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var results = JSON.parse(xhr.responseText);
            showSearchResults(results);
        }
    };

    // Ganti 'proses_pencarian.php' dengan URL yang sesuai untuk mengelola pencarian di server
    xhr.open('GET', 'proses_pencarian.php?keyword=' + keyword, true);
    xhr.send();
}

// Tambahkan event listener untuk memanggil fungsi searchPosts saat pengguna mengetik
document.getElementById('keyword').addEventListener('input', searchPosts);

</script>
