<?php
include "koneksi.php";

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Postingan</title>
</head>
<body>
    <br>
    <div class="container">
        <div class="card">
            <div class="card-body">
                    <h3>Tambah Postingan</h3>
    <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <label for="foto" class="form-label">image</label><br>
        <input type="file" name="foto" id="" class="form-control"><br>

        <label for="caption" class="form-label">caption</label><br>
        <input type="text" name="caption" id="" class="form-control"><br>

        <label for="lokasi" class="form-label">location</label><br>
        <input type="text" name="lokasi" id="" class="form-control"><br>

        <input type="submit" value="simpan" name="simpan" class="btn btn-secondary">
        <a href="index.php" class="btn btn-dark">kembali</a>

    </form>
    </div>

    </div>

    </div>

</body>
</html>