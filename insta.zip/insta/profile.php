<?php
session_start();

// Include koneksi
include "koneksi.php";
include "wrapper.php";

if (isset($_SESSION['username'])) {
    // Mendapatkan detail pengguna jika sudah login
    $username = $_SESSION['username'];

    // Inisialisasi objek mysqli
    $mysqli = new mysqli($db_host, $db_user, $db_password, $db_name);

    // Periksa koneksi database
    if ($mysqli->connect_error) {
        die("Koneksi ke database gagal: " . $mysqli->connect_error);
    }

    // Mendapatkan detail pengguna dari database
    $query = "SELECT * FROM users WHERE username = ? LIMIT 1";
    $stmt = $mysqli->prepare($query);

    if ($stmt) {
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_array(MYSQLI_ASSOC);
        $stmt->close();
    } else {
        die("Kesalahan dalam persiapan pernyataan: " . $mysqli->error);
    }
} else {
    // Jika tidak ada username dalam sesi, mungkin pengguna belum login
    // Redirect ke halaman login atau tindakan lain yang sesuai
    header("location: login.php");
}

?>
<!doctype html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

	<title>Update Profile - PHP</title>
</head>
<body>
	<div class="container">

		<div class="row">
			<div class="col-md-4 offset-md-4 mt-5">

				<?php
				if(isset($_SESSION['error'])) {
				?>
				<div class="alert alert-warning" role="alert">
				  <?php echo $_SESSION['error']?>
				</div>
				<?php
				}
				?>

				<?php
				if(isset($_SESSION['message'])) {
				?>
				<div class="alert alert-success" role="alert">
				  <?php echo $_SESSION['message']?>
				</div>
				<?php
				}
				?>


				<div class="card ">
					<div class="card-title text-center">
						<h1>Profile Form</h1>
					</div>
					<div class="card-body">
						<form action="update-profile.php" method="post">
                            <input type="hidden" name="id" class="form-control" id="id" value="<?php echo @$user['id']?>" >
							<div class="form-group">
								<label for="username">Username</label>
								<input type="text" name="username" class="form-control" id="username" value="<?php echo @$user['username']?>" aria-describedby="username" placeholder="username" autocomplete="off">

							</div>
							<div class="form-group">
								<label for="password">Password</label>
								<input type="password" name="password" class="form-control" id="password" value="<?php echo @$_SESSION['password']?>" placeholder="Password">
							</div>
							<div class="form-group">
								<label for="password">Konfirmasi Password</label>
								<input type="password" name="password_confirmation" class="form-control" id="password_confirmation" value="<?php echo @$_SESSION['password_confirmation']?>"  placeholder="Password">
							</div>

							<button type="submit" class="btn btn-primary">Update Data</button>
						</form>

						<a href="/index.php">Batal</a>
					</div>
				</div>
			</div>

		</div>

	</div>
</body>
<?php
unset($_SESSION['error']);
unset($_SESSION['message']);
?>