<?php
include "koneksi.php";

if (isset($_GET['keyword'])) {
    $keyword = $_GET['keyword'];

    // Query untuk mencari postingan berdasarkan kata kunci
    $sql = "SELECT * FROM post WHERE caption LIKE '%$keyword%' OR lokasi LIKE '%$keyword%'";
    $query = mysqli_query($koneksi, $sql);

    // Tampilkan hasil pencarian dalam bentuk HTML
    while ($post = mysqli_fetch_assoc($query)) {
        // Tampilkan informasi postingan di sini
        // Sesuaikan dengan kebutuhan Anda
        echo '<div class="card mb-4">';
        echo '<div class="card-header">';
        echo '<strong>' . $post['username'] . '</strong>';
        echo '<p>' . $post['lokasi'] . '</p>';
        echo '</div>';
        echo '<div class="img-hover-zoom">';
        echo '<img src="gambar/' . $post['foto'] . '" class="card-img-top" alt="...">';
        echo '</div>';
        echo '<div class="card-body">';
        echo '<h6 class="card-title"><strong>@' . $post['username'] . '</strong> ' . $post['caption'] . '</h6>';
        echo '<br>';
        echo '<div class="d-flex justify-content-between">';
        echo '<div>';
        echo '<a href="#"><i class="fas fa-heart fa-2x"></i></a>';
        echo '<a href="#" style="margin-left: 10px;"><i class="far fa-comment fa-2x"></i></a>';
        echo '</div>';
        echo '<div class="dropdown">';
        echo '<button class="btn btn-link" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">';
        echo '•••';
        echo '</button>';
        echo '<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">';
        echo '<a class="dropdown-item" href="#" data-toggle="modal" data-target="#exampleModal1' . $post['no'] . '">Edit</a>';
        echo '<a class="dropdown-item" href="hapus.php?no=' . $post['no'] . '">Hapus</a>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
}
?>
