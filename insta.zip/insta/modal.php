<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindlu");
}
include "koneksi.php";
$no = $_GET['no'];
$sql1 = "SELECT * FROM post WHERE no = '$no' ";
$query1 = mysqli_query($koneksi, $sql1);
?>

<div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Postingan</h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      
      <div class="modal-body">
       
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
      <?php while ($post1 = mysqli_fetch_assoc($query1))  { ?>
          <input type="hidden" name="no" value="<?=$post1['no']?>">
        <label for="foto" class="form-label">image</label><br>
        <input type="file" name="foto" id="" class="form-control" value="<?=$post1['foto']?>"><br>

        <label for="caption" class="form-label">caption</label><br>
        <input type="text" name="caption" id="" class="form-control" value="<?=$post1['caption']?>"><br>

        <label for="lokasi" class="form-label">location</label><br>
        <input type="text" name="lokasi" id="" class="form-control" value="<?=$post1['lokasi']?>"><br>

        

      </div>
      <div class="modal-footer">
      <input type="submit" value="simpan" name="simpan" class="btn btn-secondary">
        <a href="index.php" class="btn btn-dark">kembali</a> </div>
        </form>
    </div>
  </div>

    
</div>



<?php } ?>